// blueskye
/**
 * Goal tahun ini:
 * 1. Belajar JavaScript.
 * 2. Menjadi Frond-End atau Back-End Developper.
 *   */